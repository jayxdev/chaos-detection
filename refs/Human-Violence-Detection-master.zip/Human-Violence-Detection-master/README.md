# Human-Violence-Detection

Download Pre-trained Models from below links and move them to [`\Human Violence Detection\models`](https://github.com/TheAnkurGoswami/Human-Violence-Detection/tree/master/models).
## Model Links:
Openpose model: [Click here to download](https://drive.google.com/file/d/1YuJB9I7F1plPab3vjmiwqkRH_c7-aVKQ/view?usp=sharing)<br>
YOLO model: [Click here to download](https://drive.google.com/file/d/14ufVFdTUgYO__KrDdsLKBPUmMhuLaXUx/view?usp=sharing)





## Star History

<a href="https://star-history.com/#TheAnkurGoswami/Human-Violence-Detection&Date">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=TheAnkurGoswami/Human-Violence-Detection&type=Date&theme=dark" />
    <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=TheAnkurGoswami/Human-Violence-Detection&type=Date" />
    <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=TheAnkurGoswami/Human-Violence-Detection&type=Date" />
  </picture>
</a>
